package information;

public class Stop {

}
