class ArrayTwo {
  public static void main(String[] args) {
    int [] varx;
    int vary [];
    int [] vara, varb, varc;
    int vard[], vare, varf;
    
  }
}