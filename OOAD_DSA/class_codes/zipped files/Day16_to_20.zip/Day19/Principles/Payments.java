interface Payments{
  void payMoneyThroughBank();
  void getScratchCard();
  void getCashBack();
  void getDiscounts();
}

