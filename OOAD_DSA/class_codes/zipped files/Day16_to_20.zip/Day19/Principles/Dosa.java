public class Dosa {
  String type;
  int number;
}

class RavaDosa extends Dosa {
  // 
}