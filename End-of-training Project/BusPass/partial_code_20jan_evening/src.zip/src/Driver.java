import operations.AppDriver;

/*
 * the entry point for application
 * 
 * application starts by calling the initiate function of AppDriver 
 */

public class Driver {

	public static void main(String[] args) {
		AppDriver appDriver = new AppDriver();
		appDriver.initiate();
	}

}
