package com.atlas.regular;


public class Regex {
	public static void main(String args[]) {
		com.atlas.demo.One obja = new com.atlas.demo.One();
		obja.met_a();
	}
}