class Two {
  public static void main(String[] args) {
    int [] [] arr = {{10, 20, 30}, {14, 24, 34}};
    int [] [] brr = new int [2] [3];
    System.out.println("values before passing to modifcation method");
    display(arr);
  // System.out.println("values after passing to modifcation method");
  //  display(arr);

  }

  static void modifyValues(int crr[])
  {
    for(int i=0; i<crr.length; i++)
      {
        crr[i] = crr[i] - 4;
      }  

  }


  
  static void display(int arr[][]){
    for(int i=0; i<arr.length; i++)
      {
        for (int j =0; j< arr[0].length; j++){
          System.out.println(arr[i][j] + " ");
        }
        System.out.println();
      }    
  }
}