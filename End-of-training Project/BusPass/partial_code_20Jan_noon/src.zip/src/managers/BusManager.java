package managers;

import information.Bus;
import customExceptions.AppException;

public class BusManager extends BaseManager{

	public static BusManager getInstance() {
		return null;
	}
	
	public boolean displayAllBuses() throws AppException{
		
//		String [] columns = {"busid", }
		
		
		return true;
	}
	

}
