int gb = 30;

class One {

int ga = 30;
  
  public static void main(String[] args) {
    System.out.println("Hello world!");
  }
  // constructors 
  // fields
  // methods 
  
public void funca(){
  int x = 100;
}

  
}

/*
class Two extends One implements Three{
  
}*/