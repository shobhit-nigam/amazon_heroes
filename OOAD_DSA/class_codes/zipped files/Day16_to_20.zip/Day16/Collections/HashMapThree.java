import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class HashMapThree {
  public static void main(String[] args) {
    Map<String, Integer> one = new HashMap<String, Integer>();
    one.put("aa", 100);
    one.put("dd", 63);
    one.put("ww", 123);
    one.put("gg", 75);
    one.put(null, 90);
    ///////////////////////
    //forEach()
  }
}