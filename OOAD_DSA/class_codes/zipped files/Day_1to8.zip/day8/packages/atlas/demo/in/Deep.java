package com.atlas.demo.in;

public class Deep {
	public void met_d() {
		System.out.println("from met_d of Deep");
	}
}
