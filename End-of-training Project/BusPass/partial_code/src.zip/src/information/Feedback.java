package information;

public class Feedback {

}
