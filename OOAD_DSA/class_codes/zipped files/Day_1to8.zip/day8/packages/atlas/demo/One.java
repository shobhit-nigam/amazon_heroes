package com.atlas.demo;

public class One {
	public void met_a() {
		System.out.println("in method a of class One");
	}
	protected void met_b() {
		System.out.println("in method b of class One");
	}

}
