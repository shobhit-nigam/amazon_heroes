class ArrayThree {
  public static void main(String[] args) {
    int [] varx = {10, 20, 30};
    
  for (int val : varx){
    System.out.println("val = " + val);
  }
  }
}
