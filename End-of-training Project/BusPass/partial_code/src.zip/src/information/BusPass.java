package information;

public class BusPass {

}
