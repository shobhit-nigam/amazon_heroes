public class Two{
	public static void main(String [] args){
	int varx = 100;	
	int vary = 200;
	int varz = varx +  vary;
}
}
