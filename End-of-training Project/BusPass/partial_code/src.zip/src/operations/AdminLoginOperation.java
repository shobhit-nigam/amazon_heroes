package operations;

public class AdminLoginOperation {

	public static AdminLoginOperation getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
