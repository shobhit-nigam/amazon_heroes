import java.util.Stack;
import java.util.Collections;

class StackOne {
  public static void main(String[] args) {
    Stack<Integer> data = new Stack<Integer>();
    data.push(100);
    data.push(33);
    data.push(10);

    System.out.println(data);
  }
  
}